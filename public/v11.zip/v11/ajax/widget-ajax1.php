<!-- dummy file -->
<div class="inner-spacer">
    <p>Using attribute <code>data-widget-load="widget-ajax2.php"</code> we can specify source of AJAX loading data, using with <code>data-widget-refresh="15"</code> we can force widget load content automatically every 15 seconds. This example of Donut FlotChart with get dummy data from Java Script every 15 seconds.</p>
    <div class="flotchart-container">
        <div id="placeholder5" class="flotchart-placeholder"></div>
    </div>
    <div class="powerwidget-timestamp"></div>
</div>
<script>
    window.initFloatchartDemo();
</script>