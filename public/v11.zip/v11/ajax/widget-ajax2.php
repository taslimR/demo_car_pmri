<!-- dummy file -->
<div class="inner-spacer">
    <p>Without attribute <code>data-widget-refresh="boolean"</code> we can reload only pressing refresh button. This example of Pie FlotChart with get dummy data from Java Script every time you press refresh button. Also, removing <code>.powerwidget-timestamp</code> class from loaded file we get rid from timestamp at the bottom of the widget.</p>
    <div class="flotchart-container">
      <div id="placeholder6" class="flotchart-placeholder"></div>
    </div>
</div>
<script>
    window.initFloatchartDemo2();
</script>