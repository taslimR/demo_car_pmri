var svg2 = d3.select(".ms2"),

    margin2 = {top: 0, right: 35, bottom: 30, left: 50},

    width2 = +svg2.attr("width") - margin2.left - margin2.right,

    height2 = +svg2.attr("height") - margin2.top - margin2.bottom,

    g2 = svg2.append("g").attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");



var parseTime2 = d3.timeParse("%d-%b-%y");



var x2 = d3.scaleTime()

    .rangeRound([0, width2]);



var y2 = d3.scaleLinear()

    .rangeRound([height2, 0]);



var YaxisScale2 = d3.scaleLinear()

                         .domain([-30, 5])

                         .range([height2, 0], 0.3);



var prevHighSnp2 = 100;

var prevHighBg2 = 100;

var flag2 = 0;

var line3 = d3.line()

    .x(function(d) { return x2(d.date); })

    .y(function(d) {

      if(prevHighSnp2 < d.snp){

        //if(flag1 == 0){

          prevHighSnp2 = d.snp;

        //}

          return y2(275);

      }

      else if(prevHighSnp2 >= d.snp){

        //flag1 = 1;

        return y2( 275 + (d.snp - prevHighSnp2) * 6);

      }

    });





    

/*	var line2 = d3.line()

    .x(function(d) { return x1(d.date); })

    .y(function(d) {

      //BG

      if(prevHighBg1 < d.bg){

        //if(flag1 == 0){

          prevHighBg12 = d.bg;

        //}

          return y1(275);

      }

      else if(prevHighBg1 >= d.bg){

        //flag1 = 1;

        return y1( 275 + (d.bg - prevHighBg1) * 6);

      }  

    });*/

	var line4 = d3.line()

    .x(function(d) { return x2(d.date); })

    .y(function(d) {

      //BG

      if(prevHighBg2 < d.bg){

        //if(flag == 0){

          prevHighBg2 = d.bg;

        //}

          return y2(275);

      }

      else if(prevHighBg2 >= d.bg){

        //flag = 1;

        return y2( 275 + (d.bg - prevHighBg2) * 6);

      }  

    });



// var tooltip4 = d3.select("body")

//                 .select("#Summary").append("div").attr("class", "toolTip");







d3.tsv("snpAndbg.tsv", function(d) {

  d.date = parseTime2(d.date);

  d.snp = +d.snp;

  d.bg = +d.bg;

  return d;

}, function(error, data) {

  if (error) throw error;

//var prevHigh3 = 100;

  x2.domain(d3.extent(data, function(d) { return d.date; }));

  y2.domain(d3.extent(data, function(d) { return d.bg;}));



  g2.append("g")

      .attr("transform", "translate(0," + height2 + ")")

      .call(d3.axisBottom(x2));

    // .select(".domain")

      //.remove();

  g2.append("g")

  .call(d3.axisLeft(YaxisScale2))



  g2.append("path")

      .datum(data)

      .attr("fill", "none")

      .attr("stroke", "#6F95AD")

      .attr("stroke-linejoin", "round")

      .attr("stroke-linecap", "round")

      .attr("stroke-width", 1.5)

      .attr("d", line3);



  g2.append("path")

      .datum(data)

      .attr("fill", "none")

      .attr("stroke", "#0F2747")

      .attr("stroke-linejoin", "round")

      .attr("stroke-linecap", "round")

      .attr("stroke-width", 1.5)

      .attr("d", line4);

  

});